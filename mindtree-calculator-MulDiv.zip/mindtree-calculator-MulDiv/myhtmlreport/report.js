$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("calc/Caculator.feature");
formatter.feature({
  "name": "develop a calculator",
  "description": "\twith mul,div methods",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "calculator mul and div",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "open a calucltor and give \u003ca\u003e and \u003cb\u003e as input",
  "keyword": "Given "
});
formatter.step({
  "name": "something with \u0027\u003caction\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "name": "check \u003coutput\u003e is the output",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "action",
        "output"
      ]
    },
    {
      "cells": [
        "3",
        "3",
        "mul",
        "9"
      ]
    },
    {
      "cells": [
        "3",
        "-3",
        "mul",
        "-9"
      ]
    },
    {
      "cells": [
        "6",
        "3",
        "div",
        "2"
      ]
    },
    {
      "cells": [
        "12",
        "3",
        "div",
        "4"
      ]
    }
  ]
});
formatter.scenario({
  "name": "calculator mul and div",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "open a calucltor and give 3 and 3 as input",
  "keyword": "Given "
});
formatter.match({
  "location": "CaculatorStepDef.open_a_calucltor_and_give_and_as_input(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "something with \u0027mul\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "CaculatorStepDef.something_with(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "check 9 is the output",
  "keyword": "Then "
});
formatter.match({
  "location": "CaculatorStepDef.check_is_the_output(Integer)"
});
formatter.result({
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:86)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat org.junit.Assert.assertTrue(Assert.java:52)\r\n\tat com.bdd.specs.CaculatorStepDef.check_is_the_output(CaculatorStepDef.java:40)\r\n\tat ✽.check 9 is the output(calc/Caculator.feature:9)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "calculator mul and div",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "open a calucltor and give 3 and -3 as input",
  "keyword": "Given "
});
formatter.match({
  "location": "CaculatorStepDef.open_a_calucltor_and_give_and_as_input(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "something with \u0027mul\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "CaculatorStepDef.something_with(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "check -9 is the output",
  "keyword": "Then "
});
formatter.match({
  "location": "CaculatorStepDef.check_is_the_output(Integer)"
});
formatter.result({
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:86)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat org.junit.Assert.assertTrue(Assert.java:52)\r\n\tat com.bdd.specs.CaculatorStepDef.check_is_the_output(CaculatorStepDef.java:40)\r\n\tat ✽.check -9 is the output(calc/Caculator.feature:9)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "calculator mul and div",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "open a calucltor and give 6 and 3 as input",
  "keyword": "Given "
});
formatter.match({
  "location": "CaculatorStepDef.open_a_calucltor_and_give_and_as_input(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "something with \u0027div\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "CaculatorStepDef.something_with(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "check 2 is the output",
  "keyword": "Then "
});
formatter.match({
  "location": "CaculatorStepDef.check_is_the_output(Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "calculator mul and div",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "open a calucltor and give 12 and 3 as input",
  "keyword": "Given "
});
formatter.match({
  "location": "CaculatorStepDef.open_a_calucltor_and_give_and_as_input(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "something with \u0027div\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "CaculatorStepDef.something_with(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "check 4 is the output",
  "keyword": "Then "
});
formatter.match({
  "location": "CaculatorStepDef.check_is_the_output(Integer)"
});
formatter.result({
  "status": "passed"
});
});