package com.bdd.specs;

public class GreaterThanException extends Exception {
	
	public GreaterThanException(String message) {
		super(message);
		
	}

}
