package com.bdd.specs;

import static org.junit.Assert.assertTrue;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CaculatorStepDef {
	BddCalculator target = new BddCalculator();
	
	int actualoutput = 0;

	@Given("open a calucltor and give {int} and {int} as input")
	public void open_a_calucltor_and_give_and_as_input(Integer int1, Integer int2) {
		// Write code here that turns the phrase above into concrete actions

		target.setA(int1);
		target.setB(int2);
	}

	@When("something with {string}")
	public void something_with(String action) {

		if (action.equalsIgnoreCase("mul")) {
			actualoutput = target.mul();
			System.out.println(actualoutput);
		} else {
			actualoutput = target.div();
			System.out.println(actualoutput);

		}
	}

	@Then("check {int} is the output")
	public void check_is_the_output(Integer expectedOutput) {

		// System.out.println(actualoutput);
		assertTrue(expectedOutput == actualoutput ? true : false);
	}

	

}
